# RubyShell

Lightweight shell in Ruby.

Implementation is in `*.rb` files.

Executable script is in `rush` file.
