require 'mkmf'
create_makefile('delayc')