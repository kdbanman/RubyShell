swig -ruby delay.i
ruby extconf.rb 
make

